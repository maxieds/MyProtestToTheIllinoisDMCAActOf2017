#include "array.cpp"

#include "utility225.h"
#include "string.h"
#include "vehicle.h"

template class Array<pair<int, String> >;
template class Array<pair<int, Vehicle> >;
