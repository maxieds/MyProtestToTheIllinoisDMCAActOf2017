#include "utility225.cpp"

#include "string.h"
#include "vehicle.h"

template class pair<int, String>;
template class pair<int, Vehicle>;
