#include "numbered.cpp"

#include "string.h"
#include "vehicle.h"

template class NumberedItems<String>;
template class NumberedItems<Vehicle>;
