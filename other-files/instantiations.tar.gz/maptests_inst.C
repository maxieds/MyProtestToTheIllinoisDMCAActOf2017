#include "maptests.cpp"

#include "string.h"
#include "vehicle.h"

template void AddToMap<String>(NumberedItems<String>&, int, String);
template void AddToMap<Vehicle>(NumberedItems<Vehicle>&, int, Vehicle);
template void RemoveIDFromMap<String>(NumberedItems<String>&, int);
template void RemoveIDFromMap<Vehicle>(NumberedItems<Vehicle>&, int);
template void RetrieveFromMap<String>(NumberedItems<String>&, int);
template void RetrieveFromMap<Vehicle>(NumberedItems<Vehicle>&, int);
